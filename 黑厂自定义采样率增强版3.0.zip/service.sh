#!/system/bin/sh

# 日志文件路径
LOG_FILE="/data/adb/touch_opt.log"

# 配置文件路径
CONFIG_FILE="/data/adb/modules/ColorOSTouchOptimize/touch_opt.conf"

# 默认游戏进程列表
DEFAULT_GAME_PROCESSES="com.pubg.krmobile|com.tencent.ig|com.tencent.tmgp.pubgmhd|com.netease.l22|com.tencent.tmgp.sgame"

# 检查 touchHidlTest 命令是否存在
if ! command -v touchHidlTest >/dev/null; then
    echo "$(date) 未找到 touchHidlTest 命令" >> "$LOG_FILE"
    exit 1
fi

# 上次运行的游戏和当前采样率代码
LAST_RUNNING_GAME=""
CURRENT_CODE=""

# 主循环
while true; do
    # 读取配置文件
    if [ -f "$CONFIG_FILE" ]; then
        # 读取全局采样率
        GLOBAL_SAMPLE_RATE=$(grep "^global_sample_rate=" "$CONFIG_FILE" | cut -d'=' -f2 | tr -d ' ')
        GLOBAL_CODE=""
        if [ -n "$GLOBAL_SAMPLE_RATE" ] && [ "$GLOBAL_SAMPLE_RATE" -ne 0 ]; then
            case $GLOBAL_SAMPLE_RATE in
                125) GLOBAL_CODE="125" ;;  # 125表示恢复默认状态
                240) GLOBAL_CODE="1" ;;
                241) GLOBAL_CODE="special_240" ;;  # 241表示使用特殊命令设置240Hz
                360) GLOBAL_CODE="12c" ;;
                361) GLOBAL_CODE="c" ;;
                600) GLOBAL_CODE="258" ;;
                *)
                    GLOBAL_CODE=""
                    echo "$(date) 不支持的全局采样率: $GLOBAL_SAMPLE_RATE，忽略全局设置" >> "$LOG_FILE"
                    ;;
            esac
        fi

        # 获取自定义游戏列表
        CUSTOM_GAMES=$(grep '=' "$CONFIG_FILE" | grep -v '^global_sample_rate=' | cut -d'=' -f1)
        if [ -n "$CUSTOM_GAMES" ]; then
            GAME_PROCESSES=$(echo "$CUSTOM_GAMES" | tr '\n' '|' | sed 's/|$//')
        else
            GAME_PROCESSES=$DEFAULT_GAME_PROCESSES
        fi
    else
        GLOBAL_SAMPLE_RATE=0
        GLOBAL_CODE=""
        GAME_PROCESSES=$DEFAULT_GAME_PROCESSES
        echo "$(date) 未找到配置文件，使用默认设置" >> "$LOG_FILE"
    fi

    # 检查是否有游戏进程运行
    RUNNING_GAME=$(pgrep -lf "$GAME_PROCESSES" | head -n1 | awk '{print $2}')

    if [ -n "$RUNNING_GAME" ]; then
        # 游戏运行时
        if [ "$RUNNING_GAME" != "$LAST_RUNNING_GAME" ]; then
            echo "$(date) 检测到游戏 $RUNNING_GAME 启动" >> "$LOG_FILE"
            LAST_RUNNING_GAME=$RUNNING_GAME

            # 获取游戏特定采样率
            SAMPLE_RATE=$(grep "^$RUNNING_GAME=" "$CONFIG_FILE" | cut -d'=' -f2 | tr -d ' ')
            if [ -z "$SAMPLE_RATE" ]; then
                # 如果游戏未指定采样率，使用全局采样率（如果有）
                if [ -n "$GLOBAL_CODE" ]; then
                    CODE=$GLOBAL_CODE
                    echo "$(date) 游戏 $RUNNING_GAME 未指定采样率，使用全局采样率 $GLOBAL_SAMPLE_RATE" >> "$LOG_FILE"
                else
                    CODE="125"  # 恢复到默认采样率125
                    echo "$(date) 游戏 $RUNNING_GAME 未指定采样率，且无全局采样率，恢复到默认采样率 125" >> "$LOG_FILE"
                fi
            else
                # 将采样率映射到对应的代码
                case $SAMPLE_RATE in
                    125) CODE="125" ;;
                    240) CODE="1" ;;
                    241) CODE="special_240" ;;  # 241表示使用特殊命令设置240Hz
                    360) CODE="12c" ;;
                    361) CODE="c" ;;
                    600) CODE="258" ;;
                    *)
                        CODE="125"
                        echo "$(date) 不支持的采样率: $SAMPLE_RATE for $RUNNING_GAME，恢复到默认采样率 125" >> "$LOG_FILE"
                        ;;
                esac
            fi

            # 应用采样率
            if [ "$CODE" != "$CURRENT_CODE" ]; then
                if [ "$CODE" = "125" ]; then
                    if touchHidlTest -c wo 0 26 0; then
                        echo "$(date) 已为 $RUNNING_GAME 恢复到默认采样率 125" >> "$LOG_FILE"
                        CURRENT_CODE="125"
                    else
                        echo "$(date) 恢复到默认采样率 125 失败" >> "$LOG_FILE"
                    fi
                elif [ "$CODE" = "special_240" ]; then
                    if touchHidlTest -c wo 0 182 240; then
                        echo "$(date) 已为 $RUNNING_GAME 应用特殊命令设置240Hz采样率" >> "$LOG_FILE"
                        CURRENT_CODE="special_240"
                    else
                        echo "$(date) 应用特殊命令设置240Hz采样率失败" >> "$LOG_FILE"
                    fi
                else
                    if touchHidlTest -c wo 0 26 "$CODE"; then
                        echo "$(date) 已为 $RUNNING_GAME 应用代码 $CODE" >> "$LOG_FILE"
                        CURRENT_CODE="$CODE"
                    else
                        echo "$(date) 为 $RUNNING_GAME 应用代码 $CODE 失败" >> "$LOG_FILE"
                    fi
                fi
            fi
        fi
    else
        # 无游戏运行时
        if [ -n "$LAST_RUNNING_GAME" ]; then
            echo "$(date) 检测到游戏 $LAST_RUNNING_GAME 退出" >> "$LOG_FILE"
            LAST_RUNNING_GAME=""
        fi

        # 应用全局采样率（如果有）
        if [ -n "$GLOBAL_CODE" ]; then
            if [ "$GLOBAL_CODE" != "$CURRENT_CODE" ]; then
                if [ "$GLOBAL_CODE" = "125" ]; then
                    if touchHidlTest -c wo 0 26 0; then
                        echo "$(date) 已恢复到默认采样率 125" >> "$LOG_FILE"
                        CURRENT_CODE="125"
                    else
                        echo "$(date) 恢复到默认采样率 125 失败" >> "$LOG_FILE"
                    fi
                elif [ "$GLOBAL_CODE" = "special_240" ]; then
                    if touchHidlTest -c wo 0 182 240; then
                        echo "$(date) 已应用全局特殊命令设置240Hz采样率" >> "$LOG_FILE"
                        CURRENT_CODE="special_240"
                    else
                        echo "$(date) 应用全局特殊命令设置240Hz采样率失败" >> "$LOG_FILE"
                    fi
                else
                    if touchHidlTest -c wo 0 26 "$GLOBAL_CODE"; then
                        echo "$(date) 已应用全局采样率 $GLOBAL_SAMPLE_RATE (代码 $GLOBAL_CODE)" >> "$LOG_FILE"
                        CURRENT_CODE="$GLOBAL_CODE"
                    else
                        echo "$(date) 应用全局采样率 $GLOBAL_SAMPLE_RATE 失败" >> "$LOG_FILE"
                    fi
                fi
            fi
        else
            if [ "$CURRENT_CODE" != "125" ]; then
                if touchHidlTest -c wo 0 26 0; then
                    echo "$(date) 未设置全局采样率，已恢复到默认采样率 125" >> "$LOG_FILE"
                    CURRENT_CODE="125"
                else
                    echo "$(date) 恢复到默认采样率 125 失败" >> "$LOG_FILE"
                fi
            fi
        fi
    fi
    sleep 10  # 每10秒检查一次
done