#!/system/bin/sh
LOG_FILE="/data/adb/touch_opt.log"
if [ -f "$LOG_FILE" ]; then
    rm "$LOG_FILE"
    echo "$(date) 日志文件已删除" >> "$LOG_FILE"
fi