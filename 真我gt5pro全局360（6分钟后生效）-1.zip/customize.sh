ui_print "




—— 刷入の时间$(date '+%g-%m-%d %H:%M:%S')


—— 面具版本$MAGISK_VER_CODE


—— 面具代号$MAGISK_VER




"
echo "

id=dafeiyu


name=一加Ace2Pro全局120采样率240


version=全局120屏幕刷新率采样率解锁240，录屏不锁60，采样率来自酷安@int萌新很新、水竹闲士，万分感谢


versionCode=26403


author=大肥鱼


description=一加Ace2Pro全局120 [刷入时间：$(date '+%g-%m-%d %H:%M:%S')] [等候您的重启…]
" > $MODPATH/module.prop
echo "$(date '+%g-%m-%d %H:%M:%S')" > $MODPATH/time