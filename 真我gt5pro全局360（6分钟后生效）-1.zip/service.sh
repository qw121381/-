#!/system/bin/sh
Murong_Naiyi=${0%/*}
su -c sh $Murong_Naiyi/start_later.rc
