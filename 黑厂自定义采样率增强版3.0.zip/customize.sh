#!/system/bin/sh

MODDIR=${0%/*}

# 设置权限
set_perm_recursive $MODDIR 0 0 0755 0755
set_perm $MODDIR/service.sh 0 0 0755